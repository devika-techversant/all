# Myntra_Clone-Test_Task_2
This is a clone of Myntra Online Shopping Website using HTML &amp; CSS.
